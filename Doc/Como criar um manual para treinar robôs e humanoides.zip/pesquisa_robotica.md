# Pesquisa: Treinamento de Robôs e Humanoides

## Fonte 1: Movella - Metodologias de Treinamento

### Algoritmos de Aprendizado por Reforço

**PPO (Proximal Policy Optimization)**
- Algoritmo de aprendizado por reforço que treina robôs através de tentativa e erro
- Otimiza políticas que ditam ações
- Permite que robôs aprendam tarefas complexas como caminhar ou equilibrar-se
- Maximiza recompensas para comportamentos bem-sucedidos
- Estabilidade e eficiência o tornam popular para treinamento de locomoção humanoide

**GAIL (Generative Adversarial Imitation Learning)**
- Permite que robôs aprendam comportamentos observando demonstrações de especialistas
- Usa framework adversarial generativo
- Gerador tenta imitar ações de especialistas
- Discriminador avalia autenticidade das ações
- Permite aquisição de habilidades sem programação explícita de funções de recompensa

**AMP (Adversarial Motion Priors)**
- Integra dados de captura de movimento no processo de aprendizado
- Guia robôs a se moverem de forma mais humana
- Usa treinamento adversarial
- Encoraja robôs a adotarem padrões naturais de movimento
- Aumenta realismo e fluidez dos movimentos

### Frameworks de Aprendizado

**DeepMimic**
- Combina aprendizado por reforço com dados de captura de movimento
- Treina personagens simulados para realizar habilidades complexas
- Aprende a partir de movimentos de exemplo
- Robôs podem replicar comportamentos intrincados (flips, movimentos de dança)
- Adaptação a vários ambientes e tarefas

**StyleLoco**
- Framework recente que combina aprendizado por reforço com aprendizado adversarial por imitação
- Permite que robôs humanoides realizem diversas tarefas de locomoção
- Combina agilidade com estética natural
- Ponte entre performance e realismo

### Datasets de Captura de Movimento

**AMASS (Archive of Motion Capture as Surface Shapes)**
- Dataset abrangente que consolida múltiplos datasets de captura de movimento
- Formato unificado
- Vasta gama de dados de movimento humano
- Recurso valioso para treinar e avaliar algoritmos de aprendizado de movimento

**LaFAN1 (Local Action-Focused Animation Dataset)**
- Foca em sequências curtas de movimento específicas de ação
- Dados de alta qualidade para predição e interpolação de movimento
- Anotações detalhadas
- Ideal para desenvolver algoritmos que requerem compreensão precisa de movimento

### Técnicas de Animação e Controle

**Motion Matching**
- Técnica usada em animação e robótica
- Seleciona sequência de movimento mais apropriada baseada em condições atuais
- Combina movimento desejado com dados de movimento existentes
- Robôs alcançam ações mais responsivas e contextualmente apropriadas

**Teleoperação**
- Controle do robô humanoide usando captura de movimento
- Interface ao vivo entre robô e traje de captura de movimento
- Robô segue instantaneamente os movimentos do humano usando o sistema

---

## Fonte 2: MIT - Heterogeneous Pretrained Transformers (HPT)

### Desafios do Treinamento Tradicional

O treinamento tradicional de robôs de propósito geral enfrenta desafios significativos. Tipicamente, engenheiros coletam dados específicos para um determinado robô e tarefa, que são usados para treinar o robô em um ambiente controlado. No entanto, a coleta desses dados é custosa e consome tempo, e o robô frequentemente tem dificuldade em se adaptar a ambientes ou tarefas que não viu antes.

### Técnica HPT (Heterogeneous Pretrained Transformers)

Pesquisadores do MIT desenvolveram uma técnica versátil que combina uma quantidade enorme de dados heterogêneos de muitas fontes em um sistema que pode ensinar qualquer robô uma ampla gama de tarefas. O método envolve alinhar dados de domínios variados (como simulações e robôs reais) e múltiplas modalidades (incluindo sensores de visão e codificadores de posição de braço robótico) em uma "linguagem" compartilhada que um modelo de IA generativo pode processar.

### Inspiração em Modelos de Linguagem

A abordagem foi inspirada por grandes modelos de linguagem como GPT-4. Esses modelos são pré-treinados usando uma quantidade enorme de dados de linguagem diversos e depois ajustados alimentando-os com uma pequena quantidade de dados específicos da tarefa. O pré-treinamento em tantos dados ajuda os modelos a se adaptarem para ter bom desempenho em uma variedade de tarefas.

### Como Funciona

**Políticas Robóticas**: Uma "política" robótica recebe observações de sensores (como imagens de câmera ou medições proprioceptivas que rastreiam velocidade e posição de um braço robótico) e então diz ao robô como e onde se mover.

**Aprendizado por Imitação**: Políticas são tipicamente treinadas usando aprendizado por imitação, onde um humano demonstra ações ou teleopera um robô para gerar dados, que são alimentados em um modelo de IA que aprende a política. Como este método usa uma pequena quantidade de dados específicos da tarefa, os robôs frequentemente falham quando seu ambiente ou tarefa muda.

**Arquitetura Heterogênea**: Dados robóticos assumem muitas formas, desde imagens de câmera até instruções de linguagem e mapas de profundidade. Ao mesmo tempo, cada robô é mecanicamente único, com diferente número e orientação de braços, garras e sensores. Além disso, os ambientes onde os dados são coletados variam amplamente. Os pesquisadores do MIT desenvolveram uma nova arquitetura chamada Heterogeneous Pretrained Transformers (HPT) que unifica dados dessas modalidades e domínios variados.

### Vantagens da Técnica

Ao combinar uma quantidade tão enorme de dados, esta abordagem pode ser usada para treinar um robô para realizar uma variedade de tarefas sem a necessidade de começar o treinamento do zero cada vez. Este método pode ser mais rápido e menos caro do que técnicas tradicionais porque requer muito menos dados específicos da tarefa. Além disso, superou o treinamento do zero em mais de 20% em experimentos de simulação e mundo real.

### Citação de Pesquisador

"Na robótica, as pessoas frequentemente afirmam que não temos dados de treinamento suficientes. Mas na minha opinião, outro grande problema é que os dados vêm de tantos domínios, modalidades e hardware de robô diferentes. Nosso trabalho mostra como você seria capaz de treinar um robô com todos eles juntos" - Lirui Wang, estudante de pós-graduação em engenharia elétrica e ciência da computação (EECS) do MIT.

**Fonte**: https://news.mit.edu/2024/training-general-purpose-robots-faster-better-1028

---

## Fonte 3: Cornell - RHyME (Aprendizado por Vídeo)

### Sistema RHyME - Retrieval for Hybrid Imitation under Mismatched Execution

Pesquisadores da Cornell desenvolveram um framework robótico alimentado por inteligência artificial chamado **RHyME**, que permite que robôs aprendam tarefas assistindo a um único vídeo de demonstração (how-to video). Este sistema pode acelerar significativamente o desenvolvimento e implantação de sistemas robóticos ao reduzir drasticamente o tempo, energia e dinheiro necessários para treiná-los.

### Desafios do Aprendizado por Vídeo

**Problema Tradicional**: Historicamente, robôs requerem direções precisas e passo a passo para completar tarefas básicas e tendem a falhar quando as coisas saem do roteiro (como derrubar uma ferramenta ou perder um parafuso). Além disso, coletar dados no robô fazendo diferentes tarefas é um processo tedioso e demorado.

**Limitações Anteriores**: Humanos se movem de forma muito fluida para um robô rastrear e imitar, e o treinamento de robôs com vídeo requer grandes quantidades de dados. Demonstrações em vídeo devem ser realizadas lentamente e sem falhas, pois qualquer incompatibilidade nas ações entre o vídeo e o robô historicamente significava o fracasso do aprendizado.

### Como o RHyME Funciona

O RHyME é uma abordagem escalável que torna os robôs menos exigentes e mais adaptativos. Ele potencializa um sistema robótico para usar sua própria memória e conectar os pontos ao realizar tarefas que viu apenas uma vez, recorrendo a vídeos que já assistiu.

**Exemplo Prático**: Um robô equipado com RHyME que assiste a um vídeo de um humano pegando uma caneca do balcão e colocando-a em uma pia próxima irá vasculhar seu banco de vídeos e buscar inspiração de ações similares - como agarrar uma xícara e abaixar um utensílio.

### Vantagens do RHyME

- **Aprendizado de Sequências Múltiplas**: Permite que robôs aprendam sequências de múltiplas etapas
- **Redução Drástica de Dados**: Requer apenas **30 minutos de dados do robô** para treinamento (comparado a milhares de horas em métodos tradicionais)
- **Alta Taxa de Sucesso**: Em ambiente de laboratório, robôs treinados com o sistema alcançaram mais de **50% de aumento no sucesso de tarefas** comparado a métodos anteriores
- **Tradução Humano-Robô**: O trabalho funciona como "traduzir francês para inglês" - traduzindo qualquer tarefa dada de humano para robô

**Fonte**: https://news.cornell.edu/stories/2025/04/robot-see-robot-do-system-learns-after-watching-how-tos

---

## Fonte 4: NVIDIA Isaac Sim - Simulação Robótica

### NVIDIA Isaac Sim

O **NVIDIA Isaac Sim™** é um framework de referência de código aberto construído sobre o **NVIDIA Omniverse™** que permite aos desenvolvedores simular e testar soluções robóticas orientadas por IA em ambientes virtuais fisicamente realistas.

### Três Fluxos de Trabalho Essenciais

1. **Geração de Dados Sintéticos**: Para treinar ou pós-treinar modelos de robôs usados para percepção, mobilidade e manipulação, especialmente onde dados são limitados ou restritos
2. **Validação de Pilhas Robóticas**: Através de testes de software e hardware-in-loop
3. **Aprendizado de Robôs**: Habilitado através do **Isaac™ Lab**

### Recursos Principais

**Suporte a Diversos Robôs**:
- **Humanoides**: 1X, Agility, Fourier Intelligence, Sanctuary
- **Manipuladores**: Fanuc, KUKA, Universal Robots, Techman
- **Quadrúpedes**: ANYbotics, Boston Dynamics, Unitree
- **AMRs**: idealworks, iRobot

**Ativos 3D SimReady**: Acesso a mais de 1.000 ativos 3D prontos para simulação (incluindo esteiras transportadoras, caixas e paletes) para construir cenas de simulação.

**Física Realista**: Utiliza **NVIDIA PhysX®** para capacidades de física como fricção de juntas, atuação, dinâmica de corpos rígidos e macios, velocidade e muito mais.

**Suporte ROS**: Mensagens ROS2 personalizadas e URDF/MJCF agora são de código aberto. Suporte para mensagens ROS personalizadas que permitem scripting autônomo para controlar manualmente as etapas de simulação.

**OpenUSD**: Totalmente extensível, permitindo aos desenvolvedores construir simuladores personalizados baseados em Universal Scene Description (OpenUSD) ou integrar tecnologias principais do Isaac Sim em pipelines de teste e validação existentes.

### NVIDIA Isaac Lab

Framework modular de código aberto para aprendizado de robôs projetado para simplificar como os robôs aprendem e se adaptam a novas habilidades em simulação.

### NVIDIA Isaac Gym

Ambiente de física de simulação de alto desempenho otimizado para pesquisa em aprendizado por reforço. Oferece uma plataforma de aprendizado de alto desempenho para treinar políticas para uma ampla variedade de tarefas robóticas diretamente na GPU.

**Fonte**: https://developer.nvidia.com/isaac/sim

---

## Outros Simuladores de Robótica

### Gazebo

**Gazebo** é um simulador de robótica 2D/3D de código aberto que começou o desenvolvimento em 2002. É amplamente utilizado na comunidade de robótica e oferece:
- Física de alta fidelidade
- Renderização avançada
- Modelos de sensores
- Integração com ROS (Robot Operating System)
- Biblioteca rica de ferramentas e serviços em nuvem

### MuJoCo (Multi-Joint dynamics with Contact)

**MuJoCo** é um motor de física gratuito e de código aberto que visa facilitar pesquisa e desenvolvimento em robótica, biomecânica, gráficos e animação. Desenvolvido pelo Google DeepMind, é um motor de física de propósito geral amplamente usado para:
- Simulação de dinâmica multi-articular
- Pesquisa em aprendizado de máquina
- Desenvolvimento de políticas de controle
- Biomecânica e animação

### PyBullet

**PyBullet** é uma plataforma de simulação de código aberto para física em tempo real, projetada para treinar agentes incorporados (como robôs virtuais) em ambientes 3D fotorrealistas. Características:
- Interface Python simples
- Simulação de física em tempo real
- Ideal para prototipagem rápida
- Usado para pesquisa em aprendizado por reforço

---

## Principais Robôs Humanoides Comerciais para Trabalho Braçal

### 1. Tesla Optimus (Tesla Bot)

**Especificações Técnicas**:
- **Altura**: 1,73 m (5'8")
- **Peso**: 73 kg (160 lbs) na Gen 1; ~57 kg (125 lbs) na Gen 2
- **Capacidade de Carga**: 20 kg (45 lbs)
- **Capacidade de Levantamento**: 68 kg (150 lbs) do chão
- **Velocidade de Caminhada**: Melhorada na Gen 2
- **Graus de Liberdade**: Múltiplos atuadores projetados pela Tesla
- **Preço Estimado**: $20,000 - $30,000 USD (estimativas variam)

**Características**:
- Robô humanoide de propósito geral desenvolvido pela Tesla
- Atuadores e sensores projetados pela Tesla
- Mãos mais rápidas e capazes na Gen 2
- Sistema de visão baseado em IA (similar ao FSD da Tesla)
- Display facial OLED
- Implantação inicial em fábricas da Tesla em 2025
- Navegação autônoma em ambientes com obstáculos e trabalhadores humanos
- Manipulação de objetos como células de bateria

**Aplicações**:
- Trabalho em fábrica
- Logística e armazenamento
- Assistência doméstica (futuro)
- Tarefas repetitivas e perigosas

### 2. Unitree G1

**Especificações Técnicas**:
- **Altura**: 1,32 m (em pé)
- **Altura Dobrado**: 690 mm
- **Peso**: ~35 kg (com bateria)
- **Graus de Liberdade**: 23 (modelo base) / 23-43 (modelo EDU)
- **Torque Máximo do Joelho**: 90 N.m (base) / 120 N.m (EDU)
- **Carga Máxima do Braço**: ~2 kg (base) / ~3 kg (EDU)
- **Bateria**: 9000 mAh (13S lítio)
- **Autonomia**: ~2 horas
- **Preço**: $16,000 USD (modelo base)

**Características**:
- Corpo compacto e leve
- Espaço de movimento articular extra grande
- Mão diestra de três dedos com controle de força (opcional no EDU)
- Câmera de profundidade + LiDAR 3D
- Array de 4 microfones + alto-falante 5W
- CPU de 8 núcleos de alto desempenho
- Módulo NVIDIA Jetson Orin (opcional no EDU)
- Atualizações OTA contínuas
- Suporte para desenvolvimento secundário
- Motor PMSM de rotor interno de alta velocidade e baixa inércia

**Aplicações**:
- Educação e pesquisa
- Desenvolvimento de IA
- Automação leve
- Assistência e companhia

### 3. Unitree H1

**Especificações Técnicas**:
- **Altura**: ~1,78 m (tamanho completo)
- **Peso**: ~70 kg
- **Graus de Liberdade**: 21
- **Velocidade de Movimento**: <2 m/s
- **Tempo de Resposta**: 0,5 ms por junta
- **Sensores**: LiDAR 3D + Câmera de Profundidade
- **Bateria**: 15Ah (0,864 kWh), tensão máxima 67,2V
- **Preço**: $90,000 USD

**Características**:
- Robô humanoide de tamanho completo de propósito geral
- Locomoção bípede dinâmica
- Capacidade de correr e realizar movimentos atléticos
- Sensoriamento ambiental 360°
- Um dos humanoides bípedes de tamanho completo mais acessíveis para uso comercial e pesquisa

**Aplicações**:
- Pesquisa avançada em robótica
- Desenvolvimento de locomoção bípede
- Aplicações industriais
- Testes de IA e controle

### 4. Unitree R1

**Especificações Técnicas**:
- **Preço**: $5,900 USD (modelo base)
- **Graus de Liberdade**: 26 juntas
- **Características**: Reconhecimento de voz por IA, detecção de imagem
- **Capacidade**: Realizar cambalhotas (cartwheels)

**Características**:
- Robô humanoide bípede totalmente funcional
- Mais acessível que o G1
- Ágil e versátil
- Lançado em julho de 2025

**Aplicações**:
- Educação
- Pesquisa acessível
- Desenvolvimento de aplicações robóticas

### 5. Boston Dynamics Atlas (Versão Elétrica)

**Especificações Técnicas**:
- **Altura**: ~1,5 m (versão atual); gerações anteriores ~1,88 m
- **Peso**: 89 kg (versões anteriores)
- **Velocidade Máxima**: 2,5 m/s
- **Graus de Liberdade**: 28
- **Alimentação**: Totalmente elétrico (nova versão)

**Características**:
- Robô humanoide mais avançado e dinâmico do mundo
- Nova versão elétrica: mais forte, mais ágil e com maior amplitude de movimento
- Sistema de controle avançado
- Hardware de última geração
- Atletismo e agilidade avançados
- Gripper (garra) evoluído para manipulação
- Treinamento com Large Behavior Models (LBMs)
- Aprendizado por reforço com referências de captura de movimento humano
- Capacidade de agachar, abaixar costas e pernas para manipulação de média distância
- Manipulação de corpo inteiro autônoma

**Aplicações**:
- Pesquisa avançada em robótica
- Resgate e operações perigosas
- Logística industrial
- Tarefas que requerem atletismo e destreza

**Observação**: Boston Dynamics não divulga preços públicos; Atlas é principalmente para pesquisa e demonstração de capacidades.

### 6. Noetix Bumi

**Especificações Técnicas**:
- **Altura**: 94 cm (3,1 pés) - tamanho infantil
- **Peso**: 12 kg (26,5 lbs)
- **Graus de Liberdade**: Pelo menos 21
- **Bateria**: 48V com capacidade >3,5Ah
- **Autonomia**: 1-2 horas por carga
- **Preço**: ¥9,998 (~$1,370 USD)

**Características**:
- **Robô humanoide mais barato do mundo**
- Primeiro robô humanoide de grau consumidor abaixo de ¥10,000
- Materiais compostos leves
- Sistema de controle de movimento desenvolvido internamente
- Design modular simplificado
- Programação gráfica drag-and-drop para crianças e iniciantes
- Interação por voz
- Capacidade de caminhar, equilibrar e dançar com estabilidade
- Desenvolvido pela Noetix Robotics (Beijing, fundada em 2023)

**Aplicações**:
- Educação
- Uso doméstico
- Companheiro de aprendizado
- Assistente pessoal básico
- Mercado consumidor de massa

**Observação**: Não é projetado para trabalho industrial pesado, mas representa uma nova categoria de robôs humanoides acessíveis para educação e uso doméstico.

### Comparação de Preços (2025)

| Robô | Preço (USD) | Categoria |
|------|-------------|-----------|
| Noetix Bumi | $1,370 | Ultra-acessível / Educacional |
| Unitree R1 | $5,900 | Acessível / Educacional |
| Unitree G1 | $16,000 | Intermediário / Pesquisa |
| Tesla Optimus | $20,000-$30,000* | Industrial / Comercial |
| Unitree H1 | $90,000 | Profissional / Pesquisa |
| Boston Dynamics Atlas | Não divulgado** | Pesquisa Avançada |

*Estimativas; preço oficial não confirmado
**Geralmente não disponível para venda comercial

---

